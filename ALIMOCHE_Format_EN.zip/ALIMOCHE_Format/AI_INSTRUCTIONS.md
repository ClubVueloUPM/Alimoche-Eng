# ALIMOCHE · Instructions for the AI that writes or converts documents

These instructions are for an AI (Claude or another) that receives this package in a chat or a project. Its job: **turn the material provided by the project lead (usually a Word file with research) into an ALIMOCHE document** and return the **Typst master (`.typ`)** and its **PDF**.

The format is defined in `documents/ALM-FMT-01/ALM-FMT-01_Rev-0.1.pdf` (format standard, typeset with the template itself). Read it before starting: it is the visual and rule reference. This file summarises the operational part.

**The output language is English (British spelling), and only English.** If the source is in Spanish or any other language, translate it faithfully (see §4).

---

## Text to paste into the chat

> Attached are the ALIMOCHE format kit (`ALIMOCHE_Format_EN.zip`) and a document with my research. Unzip the kit, read `AI_INSTRUCTIONS.md` and the standard `ALM-FMT-01`, and convert my document into an ALIMOCHE document in English using the template. Code: `<CODE>`. Title: `<TITLE>`. Type: `<TYPE>`. Author: `<NAME>`. Revision `0.1`, status Draft, date `<DD/MM/YYYY>`. Return a ZIP with the complete `documents/<CODE>/` folder (`.typ`, `figures/`, `data/` and the PDF) and the PDF on its own as well.

If the project lead gives no code, title, type or author, ask once; if there is no answer, use what appears in the input document and flag it in the final summary.

---

## 1. Set up the environment

```bash
unzip ALIMOCHE_Format_EN.zip && cd ALIMOCHE_Format
# Typst 0.15.1: if not installed, the script extracts it from tools/ (Linux x86-64)
./tools/build.sh ALM-FMT-01      # test: must write the standard's PDF
```

- On Windows: `.\tools\build.ps1 ALM-FMT-01` with `typst.exe` on the PATH.
- The warnings `unknown font family: arial` / `consolas` are normal on Linux: the template falls back to Liberation Sans (same metrics as Arial, included in `template/fonts/`) and DejaVu Sans Mono. Do not change the fonts.
- Python with `matplotlib` and `numpy` for charts; `pandoc` to read Word (`pip install --break-system-packages matplotlib numpy` if missing).

## 2. Create the document folder

```bash
cp -r documents/_NEW documents/<CODE>
mv documents/<CODE>/NEW.typ documents/<CODE>/<CODE>.typ
```

Fill in **only** the `#show: alimoche-doc.with(...)` block. Never copy or modify `template/alimoche.typ`: if something cannot be done with the template, say so in the summary instead of changing it.

## 3. Extract the content from Word

```bash
pandoc input.docx -t typst --extract-media=documents/<CODE>/figures/_word -o /tmp/draft.typ
```

That draft is **raw material, not the result**. Pandoc leaves manual numbering («= 1. Purpose»), `#blockquote`, `#align(center)[#table(... inset ...)]`, labels such as `<purpose-and-inputs>` and styling that contradicts the standard. Rewrite the content in the `.typ` following the template. Word equations usually convert well; check them.

If the input is a PDF, use `pdftotext -layout` for the text and `pdfimages -png` for the images. If it is Excel, export the required sheets to CSV in `data/`.

## 4. Content rules (non-negotiable)

1. **Do not alter data, figures, conclusions or identifiers.** You may reorder, harmonise wording and fix obvious typos. If you correct anything of substance, say so in the summary.
2. **Do not invent**: no data, references, dates, names, signatures or approvals. Anything missing or doubtful goes in `#pending[...]`.
3. **Status and revision**: whatever the project lead says. Default Draft, 0.1. Never «Approved» unless the project lead says so explicitly. The signature (`signature: image(...)`) only if he asks for it and provides the image.
4. Identifiers (ASM-01, REQ-01, CRIT-01, LEG-01...) are kept **exactly as they are**, even if their letters come from Spanish words. No superfluous zeros in new ones. Never renumber.
5. **Language**: British English only, impersonal, short sentences, no embellishment or filler bold. When translating: keep codes, identifiers, proper names, place names and aerodrome names as in the source; translate regulatory references by their official English name when one exists (e.g. EASA, AESA, Royal Decree 765/2022) and otherwise keep the original title with an English gloss in brackets; if a technical term is uncertain, choose the standard aeronautical English term and list it in the summary.

## 5. Format rules (summary of ALM-FMT-01)

| Element | How |
|---|---|
| Metadata | Only in `alimoche-doc.with(...)` → title block. No cover page, no revision history, no author/date in the body. |
| First title | Set by the template (title only). Do not add another. |
| Headings | `=` and `==`, numbered automatically. **Never type numbers by hand.** `===` unnumbered, exceptional use only. No subsection for a single paragraph. |
| Typical structure | Purpose and scope · Input data · Development (one or more sections) · Conclusions/outputs · References · Appendices. Adapt to the content; do not fill empty sections. |
| Identifiers | `#item("REQ-01", "Title")[text]`. If there are many short ones, prefer a table with an «ID» column. |
| Notes / open issues | `#note[...]` · `#pending[...]` |
| Numbers | **Decimal point** everywhere (text, tables, equations, charts): `1.04`. Thousands grouped with a thin space from 5 digits (`15 690`), never with commas or points. `#num(15690)`, `#num(0.055, dec: 3)`; with unit `#qty(9.81, "m/s²", dec: 2)`. If the source uses decimal commas, convert them to points. |
| Units | SI, space between number and unit, «Quantity (unit)» in headers and axes; dimensionless «(–)». |
| Dates | DD/MM/YYYY. |
| Tables | `#figure(table(...), caption: [...]) <tab:name>`. First row = header (the template makes it bold on grey). Text left, figures right (`align: (left, right, ...)`), same decimals per column. Do not set your own `stroke`, `fill` or `inset`. Source below with `#source[...]`. |
| Excel tables | CSV in `data/` → `#csv-table(csv("data/x.csv"), columns: (...), align: (...))`. If it comes from a continental Excel (`;` and decimal comma): `csv(..., delimiter: ";")` and `comma-to-point: true`. |
| Figures | `#figure(image("figures/x.svg", width: 100%), caption: [...]) <fig:name>`. Caption below, describing what is shown and its origin. Cite in the text before it appears: `@fig:name`, `@tab:name`, `@eq:name`. |
| Charts | **Redraw them** with `template/charts/alimoche_charts.py` whenever data or a formula are available (see §6). Only if the data cannot be obtained, keep the original image and say so in the caption. Text inside kept images that is not in English is noted in the caption. |
| Images | Photos JPG, sketches SVG/PNG ~300 dpi. Width 160 mm (full) or 78 mm (half). File names without spaces or accents. |
| Equations | `$ ... $ <eq:name>` displayed and numbered; variables defined right after («where ...»). Inline: `$q = 1/2 rho V^2$`. |
| References | `#references(([...], [...]))` at the end, before appendices. Cite in the text as [1], [2]. Only references present in the input material. |
| Appendices | `#show: appendices` then `= Title` → «Appendix A». |
| Contents | `contents: true` if longer than about 6 sheets. |
| Colour | None in text, tables or title block. In charts, only with several series and always combined with a different line style (see §6). |

## 6. Charts

One script per chart in `documents/<CODE>/figures/`, reading from `data/` (or computing) and writing the SVG with the same name. Full example: `documents/ALM-FMT-01/figures/polar_example.py`.

```python
import sys, pathlib
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[3] / "template" / "charts"))
import alimoche_charts as ac
import csv

rows = list(csv.reader(open(pathlib.Path(__file__).parents[1] / "data" / "sink.csv", encoding="utf-8")))
x = [float(r[0].replace(",", ".")) for r in rows[1:]]   # accepts CSV with comma or point
y = [float(r[1].replace(",", ".")) for r in rows[1:]]

fig, ax = ac.figure(160, 80)            # width, height in mm
ax.plot(x, y, **ac.series(0), label="Lillo 40 °C")
ax.axhline(1.0, **ac.LIMIT)             # limit / reference line
ax.set_xlabel("Airspeed (km/h)"); ax.set_ylabel("Sink rate (m/s)")
ac.legend(ax)                           # only if there is more than one series
ac.save(fig, __file__)                  # -> sink.svg
```

- No title inside the chart; the title is the figure caption.
- Single curve: solid black (`ac.series(0)`).
- Several curves: `ac.series(0)`, `ac.series(1)`... combine **colour + line style** (and a marker from the 5th), so they can also be told apart when printed in black and white. Never distinguish series by colour alone. `ac.series(i, colour=False)` gives the black/grey version.
- Bars: `ac.bars(i)` (grey); `ac.bars(i, colour=True)` adds colour and hatching.
- Axes as «Quantity (unit)». The module sets the decimal point and consistent decimals.

## 7. Build and check

```bash
./tools/build.sh <CODE>     # regenerates charts and writes <CODE>_Rev-<rev>.pdf
pdftoppm -r 70 -png documents/<CODE>/<CODE>_Rev-<rev>.pdf /tmp/rev
```

**Look at every rendered page** before delivering and check:

- [ ] Compiles without errors (Arial/Consolas warnings do not count).
- [ ] Title block correct on every sheet; «Sheet n / N» right.
- [ ] No hand-typed section numbers; no `#blockquote`, `#align(center)[#table` or custom table styling.
- [ ] All tables and figures numbered, cited in the text, captioned; no broken references («??»).
- [ ] Decimal point in text, tables, equations and charts; units with a space.
- [ ] Charts readable in black-and-white print (colour always with a different line style), no inner title, text at document size.
- [ ] Everything in English, including table headers, chart labels and legends.
- [ ] Nothing outside the frame; no large gaps from badly placed figures.
- [ ] No invented data; doubts in `#pending`.

## 8. Deliver

1. ZIP with the complete `documents/<CODE>/`: `<CODE>.typ`, `figures/` (`.py` scripts, `.svg`, images), `data/` (CSV) and `<CODE>_Rev-<rev>.pdf`. Without the `figures/_word` folder if no longer used.
2. The PDF on its own as well, for direct viewing.
3. A short summary: what was converted, which charts were redrawn and which were kept as images, what was marked as open, translation choices for uncertain terms, and any wording change that affects substance.

## 9. Revising an existing ALIMOCHE document

If the project lead provides an old PDF (Word, LibreOffice, ReportLab, the Spanish template or another one), it is treated like a Word file: the content is extracted and typeset again with this template, **keeping the code, the revision he specifies and every identifier**. Differences of form in the original (headings such as «OBJ objeto», manual numbering, decimal commas, series distinguished by colour alone, different title blocks) are corrected; differences of substance are not: they are flagged.
