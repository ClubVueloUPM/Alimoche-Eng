// ALIMOCHE document skeleton.
// 1) Copy the _NEW folder as documents/<CODE>/ and rename this file to <CODE>.typ
// 2) Fill in the metadata (only here; the template puts them in the title block)
// 3) Compile from the package root:
//    typst compile --root . --font-path template/fonts documents/<CODE>/<CODE>.typ documents/<CODE>/<CODE>_Rev-0.1.pdf
#import "../../template/alimoche.typ": *

#show: alimoche-doc.with(
  code: "ALM-XX",
  title: "Document title",
  doctype: "Supporting study",     // Specification · Supporting study · Technical note · Internal standard · Guide ...
  revision: "0.1",
  status: "Draft",                 // Draft · In review · Approved · Obsolete
  created: "DD/MM/YYYY",
  modified: none,                  // date of last revision; none = same as «created»
  author: "Name Surname",
  checker: "Pending",
  approved-by: "Pending",
  contents: false,                 // true if the document exceeds about 6 sheets
)

= Purpose and scope

Which question the document answers, which documents it starts from and what it delivers.

= Input data

#figure(
  table(
    columns: (1fr, 30mm, 1fr),
    align: (left, right, left),
    [Quantity], [Value], [Origin],
    [Target empty mass], [#qty(70, "kg")], [ALM-00],
  ),
  caption: [Input data.],
) <tab:inputs>

= Development

Text. Cite tables and figures before they appear: @tab:inputs.

#item("ASM-01", "Assumption title")[
  Statement of the assumption.
]

// #figure(image("figures/chart.svg", width: 100%), caption: [Description.]) <fig:chart>

= Conclusions

Results produced by the document and which documents they feed.

#references((
  [Author. _Title_. Publisher or link, year.],
))

// #show: appendices
// = Appendix title
