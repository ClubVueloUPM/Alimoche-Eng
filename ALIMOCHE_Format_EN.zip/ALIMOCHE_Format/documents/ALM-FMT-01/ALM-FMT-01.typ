#import "../../template/alimoche.typ": *

#show: alimoche-doc.with(
  code: "ALM-FMT-01",
  title: "Document format standard",
  doctype: "Internal standard",
  revision: "0.1",
  status: "Draft",
  created: "28/10/2026",
  author: "Augusto Aizpún",
  checker: "Pending",
  approved-by: "Pending",
  contents: true,
)

= Purpose and scope

This standard defines the *appearance* of every ALIMOCHE document: page, title block, typography, headings, tables, charts, figures, equations and the way numbers and units are written. Its aim is that any document, whether written by a person or by an AI, is indistinguishable in form from the rest.

It does not define the structure of the document set (document tree, codes, dependencies or final file names). That will be covered by a later document. Until then, codes follow current local practice (ALM-00, ALM-P00, ALM-P00-A01...) and the code of this standard itself is provisional.

Everything shown here is typeset with the template itself: this PDF is both the standard and the reference sample.

= Tools and files

The master of every document is its *Typst* file (`.typ`). The PDF is a derivative regenerated at compile time; the PDF is never edited and no parallel Word file is kept. Typst 0.15.1 is used.

#figure(
  table(
    columns: (44mm, 1fr),
    align: (left, left),
    [Path], [Content],
    [`template/alimoche.typ`], [Common template. No document copies or modifies it; all of them import it.],
    [`template/resources/`], [Official logos and watermark.],
    [`template/fonts/`], [Liberation Sans, a metric-compatible substitute for Arial on machines without it.],
    [`template/charts/`], [Python module with the common chart style.],
    [`documents/<CODE>/`], [One folder per document: `<CODE>.typ`, `figures/`, `data/` and the PDF.],
  ),
  caption: [File organisation.],
)

Documents are compiled from the package root folder:

```
typst compile --root . --font-path template/fonts documents/ALM-FMT-01/ALM-FMT-01.typ documents/ALM-FMT-01/ALM-FMT-01_Rev-0.1.pdf
```

For live preview, use VS Code with the Tinymist extension, opening the package root folder.

= Page, title block and footer

The sheet is A4 portrait. A 0.8 pt frame, 10 mm from the paper edge, encloses the page. The title block of @tab:titleblock sits at the top of the frame on every sheet, with the square logo on the left. The footer, inside the frame, repeats code, revision and status on the left and «ALIMOCHE PROJECT» on the right. The watermark is the lightened circular seal, centred, 125 mm wide.

#figure(
  table(
    columns: (40mm, 1fr),
    align: (left, left),
    [Field], [Content],
    [Document], [Document title, without the code.],
    [Code], [Document identifier (e.g. ALM-P00-A06).],
    [Revision], [0.1, 0.2... while drafting; 1.0 at first approval.],
    [Sheet], [Current sheet / total. Automatic.],
    [Type], [Kind of document: Specification, Supporting study, Technical note, Internal standard...],
    [Created / last revised], [Dates DD/MM/YYYY. If they coincide, only one is shown.],
    [Status], [Draft, In review, Approved or Obsolete. The template rejects any other value.],
    [Prepared by], [Author or authors.],
    [Checked by], [Person who checks the technical content; «Pending» until assigned.],
    [Approved by], [Name of the approver and, only if the project lead says so, their signature.],
  ),
  caption: [Title block fields.],
) <tab:titleblock>

Metadata appear only in the title block. The body does not repeat author, date, revision or status, and has no cover page or revision history. On the first sheet, below the title block, only the centred title is written. A table of contents is added (`contents: true`) only if the document exceeds about six sheets.

No colour is used in text, tables or title block; the only fill allowed is the light grey of table headers. The single exception is charts with several series (@sec:charts). Logos are never distorted, cropped or recoloured; inside the body they are used only when the logo itself is the subject.

= Typography and writing

#figure(
  table(
    columns: (1fr, 26mm, 1fr),
    align: (left, left, left),
    [Element], [Size], [Style],
    [Body text], [10 pt], [Arial, justified, hyphenated, line spacing approx. 1.15],
    [Document title], [14 pt], [Bold, centred, first sheet only],
    [Level 1 heading], [12 pt], [Bold, numbered: «3 Page, title block and footer»],
    [Level 2 heading], [10.5 pt], [Bold, numbered: «3.1 ...»],
    [Level 3 heading], [10 pt], [Bold, unnumbered; exceptional use],
    [Tables], [9 pt], [Left-aligned, not justified],
    [Table and figure captions], [8.5 pt], [Bold label: «Table 2.» / «Figure 1.»],
    [Data source], [8 pt], [Grey, below the table or figure],
    [Code and paths], [8.5 pt], [Monospaced (Consolas or DejaVu Sans Mono)],
    [Equations], [10 pt], [New Computer Modern Math, numbered on the right],
  ),
  caption: [Typography.],
)

The typeface is Arial. On machines without Arial the template uses Liberation Sans, which occupies exactly the same space, so pagination does not change.

== Writing

Documents are written in British English, in an impersonal style or the first person plural, with short sentences and no embellishment. Each section should be readable without consulting others. Bold is avoided except for the conclusion or figure that matters in a paragraph. No subsection is created for a single paragraph: as a rule, two heading levels at most.

Items with their own identifier (assumptions ASM, requirements REQ, criteria CRIT...) are presented with their code, which speaks for itself, without a section number in front. Codes carry no superfluous zeros: ASM-01, REQ-12. Once issued, they are never renumbered.

#item("ASM-01", "Flight environment (example)")[
  Lillo aerodrome (LELT), elevation 681 m, 40 °C, density #qty(1.04, "kg/m³", dec: 2). Any identified assumption, requirement or criterion is written like this.
]

#note[Notes clarify something without interrupting the argument. Use them sparingly.]

#pending[Open issues are marked like this so they stand out during review. An approved document must not contain any.]

== Numbers, units and dates

A *decimal point* (#num(1.04, dec: 2)) and SI units are used throughout: text, tables, equations and charts. Numbers of five or more digits are grouped in threes with a thin space (#num(15690)); four-digit numbers are not (#num(1569)). Neither commas nor points are ever used as thousands separators. A non-breaking space always separates number and unit: #qty(160, "kg"), #qty(9.81, "m/s²", dec: 2), #qty(40, "°C"). The exception is a percentage attached to the number in tables or short brackets.

In the template, `#num(x, dec: n)` and `#qty(x, "unit", dec: n)` do this automatically and fix the number of decimals.

Dates are written DD/MM/YYYY. Quantities in table headers and chart axes are written «Quantity (unit)»; dimensionless ones «(–)».

= Tables

Tables have 0.5 pt black rules on every cell, a bold header on light grey and 9 pt text. The caption goes *above*: «Table n. Text». The source, where relevant, goes below. Text is left-aligned and figures right-aligned, with the same number of decimals throughout a column. Every table is cited in the text before it appears.

A table can be written directly in Typst (@tab:titleblock) or read from a CSV exported from Excel, as in @tab:mass. The CSV is stored in `data/` exactly as exported and never edited by hand: if the data change, it is exported again. If Excel exports with «;» and decimal commas (continental locales), `comma-to-point: true` converts the figures to decimal points when the table is typeset.

#figure(
  csv-table(csv("data/mass_example.csv"), columns: (1fr, 30mm, 30mm)),
  caption: [Example mass breakdown read from `data/mass_example.csv`.],
) <tab:mass>
#source[illustrative values; they are not an ALIMOCHE mass budget.]

Long tables may break across sheets; the header repeats automatically. Merged cells are avoided unless essential.

= Figures and charts

Every image, sketch or chart is a numbered figure with its caption *below*: «Figure n. Text». The caption describes what is shown and, where relevant, the source or calculation conditions. Every figure is cited in the text before it appears.

== Charts <sec:charts>

Charts are produced with Python and the module `template/charts/alimoche_charts.py`, which fixes the style: light grid, no top or right spine, decimal point and text in the document typeface.

A chart with a single curve is black with a solid line. With several curves colour is allowed, but *always combined* with a different line style (solid, dashed, dash-dot, dotted) and, from the fifth series on, a marker. The chart then reads the same when printed in black and white. The module provides these combinations in order through `series(0)`, `series(1)`...; `series(i, colour=False)` gives the black-and-grey variant. Bars are grey; if coloured, they also carry hatching. Charts are saved as SVG, which stays sharp at any scale. The chart has no title inside it: the title is the figure caption.

Each chart has its script in `figures/` and reads its data from `data/` or computes them, so anyone can regenerate it. The normal width is 160 mm (full) or 78 mm (half, two side by side). @fig:polar is the reference example.

#figure(
  image("figures/polar_example.svg", width: 100%),
  caption: [Example parabolic drag polar, $C_D = C_(D 0) + k C_L^2$ with $C_(D 0) = 0.055$, for three values of the Oswald factor. Each series combines colour and line style. The dashed vertical line marks the assumed $C_(L,max)$.],
) <fig:polar>

== Images and photographs

Photographs are JPG and sketches SVG or PNG, with enough resolution to print at their size (about 300 dpi). The author or origin is stated in the caption. Third-party images are used only if their origin can be given. @fig:logo shows how an image is handled.

#figure(
  image("figures/logo_example.jpeg", width: 70mm),
  caption: [Example of an image inserted at fixed width. Source: ALIMOCHE graphic resources.],
) <fig:logo>

= Equations

Equations that are referred to are displayed and numbered on the right; short ones may stay in the text, as $q = 1/2 rho V^2$. Variables are defined the first time they appear, right after the equation.

$ C_D = C_(D 0) + k C_L^2, quad k = 1 / (pi "AR" e) $ <eq:polar>

where $C_(D 0)$ is the zero-lift drag coefficient, $"AR"$ the aspect ratio and $e$ the Oswald factor. @eq:polar is the basis of @fig:polar.

= Status, revisions and file names

A document is born as «Draft» at revision 0.1 and moves to 0.2, 0.3... with each version shared. It becomes «In review» when handed to a checker, and «Approved», at revision 1.0, only when the project lead explicitly approves it. Changing the status in the file is not approval. Revisions after approval are 1.1, 1.2... and the next approval 2.0. A superseded document becomes «Obsolete».

Provisionally, the master is named `<CODE>.typ` and the PDF `<CODE>_Rev-<n.n>.pdf` (e.g. `ALM-P00-A06_Rev-0.3.pdf`). The document-structure standard may change this rule.

#pending[Document tree, code assignment, parent-child relations and final file names: to be defined in a later document.]

= Converting existing documents

A study written in Word, or a PDF produced with another tool, is converted as follows: text, tables, equations and images are extracted; the content is reorganised according to this standard without altering data, conclusions or identifiers; and it is typeset in Typst with the template. Charts that can be regenerated from data are redrawn with the common module; the rest are kept as images. Anything missing or doubtful is marked as open rather than invented. The detailed procedure for the AI is in `AI_INSTRUCTIONS.md`.

#references((
  [Typst. _Typst documentation_, version 0.15. https://typst.app/docs],
  [ALIMOCHE. ALM-P00-A06 _Preliminary aerodynamic estimate_, Rev. 0.2, 25/10/2026.],
))

#show: appendices

= Template function summary

#figure(
  table(
    columns: (58mm, 1fr),
    align: (left, left),
    [Function], [Use],
    [`#show: alimoche-doc.with(...)`], [Header of every document: code, title, type, revision, status, dates, author, checker, approver, contents.],
    [`= Heading` / `== Heading`], [Level 1 and 2 headings, numbered.],
    [`#item("REQ-01", "Title")[...]`], [Assumption, requirement or criterion with identifier.],
    [`#note[...]`, `#pending[...]`], [Clarifying note; open issue.],
    [`#num(x, dec: n)`, `#qty(x, "u", dec: n)`], [Number with decimal point and thin-space thousands; quantity with unit.],
    [`#figure(table(...), caption: [...]) <tab:x>`], [Numbered table; cite with `@tab:x`.],
    [`#csv-table(csv("data/x.csv"))`], [Table from an Excel CSV (`comma-to-point: true` if it has decimal commas).],
    [`#figure(image("figures/x.svg"), caption: [...]) <fig:x>`], [Numbered figure; cite with `@fig:x`.],
    [`#source[...]`], [«Source: ...» line below a table or figure.],
    [`$ ... $ <eq:x>`], [Numbered equation; cite with `@eq:x`.],
    [`#references((...))`], [Final list of references [1], [2]...],
    [`#show: appendices`], [From there on, headings become «Appendix A», «Appendix B».],
  ),
  caption: [Template functions.],
)
