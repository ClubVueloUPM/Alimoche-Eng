"""Example figure for ALM-FMT-01: parabolic drag polar (values from ALM-P00-A06 Rev. 0.2)."""
import sys, pathlib
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[3] / "template" / "charts"))
import alimoche_charts as ac
import numpy as np

CD0, k = 0.055, 0.0455
CL = np.linspace(0, 1.5, 61)
fig, ax = ac.figure(160, 72)
ax.plot(CL, CD0 + k * CL**2, **ac.series(0), label="e = 0.70 (baseline)")
ax.plot(CL, CD0 + 0.8 * k * CL**2, **ac.series(1), label="e = 0.875 (sensitivity)")
ax.plot(CL, CD0 + 0.7 * k * CL**2, **ac.series(2), label="e = 1.00 (ideal elliptic wing)")
ax.axvline(1.5, **ac.LIMIT)
CLopt = (CD0 / k) ** 0.5
ax.plot([CLopt], [2 * CD0], marker="o", markersize=4, color="black", markerfacecolor="white", linestyle="none")
ac.annotate(ax, "Best glide ratio (baseline)", (CLopt, 2 * CD0), (0.72, 0.035))
ax.set_xlabel("Lift coefficient $C_L$ (–)")
ax.set_ylabel("Drag coefficient $C_D$ (–)")
ax.set_xlim(0, 1.6); ax.set_ylim(0, 0.17)
ac.legend(ax, loc="upper left")
ac.save(fig, __file__)
