# ALIMOCHE · Document format kit (Typst) — English edition

**Kit version:** 28/10/2026 · Typst 0.15.1

This package defines **the format** of ALIMOCHE documents in English and lets an AI in a new chat convert a research Word file (in English or Spanish) into an ALIMOCHE document (`.typ` + PDF). It is the English counterpart of the Spanish kit (`ALIMOCHE_Formato`); both produce identical layouts. The **document structure** (tree, codes, final names) is left for a later document.

## Contents

```text
README.md                   this file
AI_INSTRUCTIONS.md          what the AI reads: Word -> Typst -> PDF workflow, rules and checks
template/
  alimoche.typ              common template (frame, title block, styles, functions). Never edited per document
  resources/                logos and watermark
  fonts/                    Liberation Sans (metric-compatible substitute for Arial)
  charts/alimoche_charts.py common chart style (matplotlib -> SVG)
documents/
  ALM-FMT-01/               format standard: .typ, PDF, example chart with its script, example CSV
  _NEW/                     skeleton to start a document
tools/
  build.sh / build.ps1      build a document by its code
  typst-0.15.1-linux-x86_64.tar.xz   Typst for the AI's Linux environment
```

## Use with an AI

1. In a new chat or project, attach `ALIMOCHE_Format_EN.zip` and your Word file.
2. Paste the text in the «Text to paste into the chat» section of `AI_INSTRUCTIONS.md`, with code, title, type, author and date.
3. The AI returns a ZIP with `documents/<CODE>/` and the PDF. Copy that folder into your `documents/`.

## Use on your computer (Windows)

1. Typst 0.15.1 (`typst.exe` on the PATH) and, for live preview, VS Code + the **Tinymist** extension. Open the `ALIMOCHE_Format` folder (the root, not the document's folder) in VS Code.
2. Build: `.\tools\build.ps1 ALM-P00-A06` → `documents\ALM-P00-A06\ALM-P00-A06_Rev-0.2.pdf`.
3. For a new document, copy `documents\_NEW` as `documents\<CODE>` and rename the `.typ`.

## What this kit fixes and what it does not

- **Fixed:** A4 page with frame, title block on every sheet, watermark, footer, Arial 10 pt justified, two numbered heading levels, ASM/REQ/CRIT identifiers as their own block, black-ruled tables with light-grey header, «Table n.» captions above and «Figure n.» below, charts from Python (black; colour only with several series and always combined with line style), decimal point, numbered equations, no cover page, revision history or colour elsewhere.
- **Provisional:** the code `ALM-FMT-01` of the standard and the file name `<CODE>_Rev-<n.n>.pdf`.
- **Pending (document 2):** document tree, code assignment, parent/dependencies, final names.
- **Note:** the logo artwork reads «PROYECTO ALIMOCHE»; it is an image and is used unchanged.
