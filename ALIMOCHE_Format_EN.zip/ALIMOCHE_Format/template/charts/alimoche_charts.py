"""
ALIMOCHE PROJECT · Common chart style (defined by ALM-FMT-01)

Use in each document's chart script (documents/<CODE>/figures/<name>.py):

    import sys, pathlib
    sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[3] / "template" / "charts"))
    import alimoche_charts as ac

    fig, ax = ac.figure()                       # 160 x 80 mm by default
    ax.plot(x, y1, **ac.series(0), label="Lillo 40 °C")
    ax.plot(x, y2, **ac.series(1), label="ISA sea level")
    ax.set_xlabel("Airspeed (km/h)"); ax.set_ylabel("Sink rate (m/s)")
    ac.legend(ax)
    ac.save(fig, __file__)                      # writes <name>.svg next to the script

Rules:
- Single curve: black, solid line (series(0)).
- Several curves: colour is allowed, but ALWAYS combined with a different line
  style (and a marker from the 5th series on), so the chart reads the same when
  printed in black and white. series(i) already gives that combination.
  series(i, colour=False) gives the black/grey-only variant.
- No title inside the chart (the title is the Typst figure caption), axes as
  "Quantity (unit)", decimal point, light grid, SVG with text kept as text.
"""
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.ticker import FuncFormatter

MM = 1 / 25.4  # inches per mm

# Sober, distinguishable colours (colour-blind friendly); the first is always black
COLOURS = ["#000000", "#1f4e9c", "#b2182b", "#1b7837", "#d07a00", "#6a3d9a"]
GREYS = ["#000000", "#000000", "#555555", "#555555", "#000000", "#555555"]
LINESTYLES = ["-", "--", "-.", ":", "-", "-"]
MARKERS = [None, None, None, None, "o", "s"]

# Bar fills (in order); add hatching when colours are used
BARS = ["#404040", "#9a9a9a", "#d0d0d0", "white"]
HATCHES = ["", "//", "..", "xx"]
# Reference / limit lines (e.g. maximum mass, VNE)
LIMIT = dict(color="#000000", linestyle=(0, (6, 3)), linewidth=0.8)


def _formatter(axis):
    """Decimal point with the same number of decimals on every tick of the axis."""
    def f(x, _pos):
        dec = 0
        for v in axis.get_majorticklocs():
            t = f"{v:.6f}".rstrip("0").rstrip(".")
            dec = max(dec, len(t.split(".")[1]) if "." in t else 0)
        s = f"{x:.{dec}f}"
        if float(s) == 0:
            s = s.lstrip("-")
        return s.replace("-", "−")
    return FuncFormatter(f)


def style():
    matplotlib.rcParams.update({
        "font.family": "sans-serif",
        "font.sans-serif": ["Arial", "Liberation Sans", "DejaVu Sans"],
        "font.size": 8.5,
        "axes.labelsize": 8.5,
        "xtick.labelsize": 8,
        "ytick.labelsize": 8,
        "legend.fontsize": 8,
        "axes.linewidth": 0.6,
        "axes.edgecolor": "black",
        "axes.spines.top": False,
        "axes.spines.right": False,
        "axes.grid": True,
        "grid.color": "#c8c8c8",
        "grid.linewidth": 0.4,
        "grid.linestyle": "-",
        "lines.linewidth": 1.1,
        "xtick.direction": "out",
        "ytick.direction": "out",
        "xtick.major.width": 0.6,
        "ytick.major.width": 0.6,
        "legend.frameon": False,
        "savefig.transparent": True,   # lets the watermark show through, like the text
        "svg.fonttype": "none",        # Typst sets the text in the document font
        "axes.formatter.use_mathtext": False,
    })


def figure(width_mm=160, height_mm=80, rows=1, cols=1, **kw):
    """Create a figure in ALIMOCHE style. Allowed widths: 160 (full) or 78 (half)."""
    style()
    fig, ax = plt.subplots(rows, cols, figsize=(width_mm * MM, height_mm * MM),
                           layout="constrained", **kw)
    for a in (ax.flat if hasattr(ax, "flat") else [ax]):
        a.xaxis.set_major_formatter(_formatter(a.xaxis))
        a.yaxis.set_major_formatter(_formatter(a.yaxis))
    return fig, ax


def series(i, colour=True):
    """Style of series i (0, 1, 2...): colour + line style (+ marker), always combined."""
    k = i % len(LINESTYLES)
    d = dict(color=(COLOURS if colour else GREYS)[k], linestyle=LINESTYLES[k])
    if MARKERS[k]:
        d.update(marker=MARKERS[k], markersize=3.5, markerfacecolor="white", markevery=0.1)
    return d


def bars(i, colour=False):
    """Fill of bar series i: grey by default; colour=True adds colour and hatching."""
    k = i % len(BARS)
    if colour:
        return dict(color=COLOURS[k], edgecolor="black", linewidth=0.5, hatch=HATCHES[k])
    return dict(color=BARS[k], edgecolor="black", linewidth=0.5)


def legend(ax, **kw):
    ax.legend(loc=kw.pop("loc", "best"), handlelength=2.6, **kw)


def annotate(ax, text, xy, xytext):
    """Plain annotation with a thin leader line (to point out a design point)."""
    ax.annotate(text, xy=xy, xytext=xytext, fontsize=7.5,
                arrowprops=dict(arrowstyle="-", linewidth=0.5, color="black"))


def save(fig, script_or_path, name=None):
    """Save <name>.svg next to the script (or at the given path)."""
    p = Path(script_or_path)
    target = p.with_suffix(".svg") if name is None else p.parent / f"{name}.svg"
    fig.savefig(target, format="svg")
    plt.close(fig)
    return target
