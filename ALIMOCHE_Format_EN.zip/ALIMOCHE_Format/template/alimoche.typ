// =====================================================================
//  ALIMOCHE PROJECT · Common document template (Typst 0.15.1)
//  Format defined by ALM-FMT-01. Do NOT copy or edit it per document:
//  every document imports it with  #import "../../template/alimoche.typ": *
//  and opens with                   #show: alimoche-doc.with(...)
// =====================================================================

// ---------- Format constants -------------------------------------------
#let FONT = ("Arial", "Liberation Sans")         // Liberation Sans = same metrics as Arial
#let FONT-MONO = ("Consolas", "DejaVu Sans Mono")
#let BLACK = rgb("000000")
#let GREY = rgb("555555")                          // secondary text (footer, sources)
#let LIGHT-GREY = rgb("e6e6e6")                    // only fill allowed (table header)
#let STROKE-FRAME = 0.8pt + BLACK
#let STROKE-TITLEBLOCK = 0.6pt + BLACK
#let STROKE-TABLE = 0.5pt + BLACK
#let STATUSES = ("Draft", "In review", "Approved", "Obsolete")

// Geometry (A4: 210 × 297 mm)
#let FRAME-MARGIN = 10mm    // distance from frame to paper edge
#let TITLEBLOCK-H = 33mm    // title block height
#let LOGO = "resources/logo-square.jpeg"
#let WATERMARK = "resources/logo-watermark.png"

// ---------- Numbers: decimal point, thin-space thousands ---------------
// num(1569) -> 1569 · num(15690) -> 15 690 · num(0.055, dec: 3) -> 0.055
#let num(x, dec: none) = {
  let v = if dec == none { x } else { calc.round(x, digits: dec) }
  let neg = v < 0
  let s = str(calc.abs(v))
  if dec != none and dec > 0 {
    if not s.contains(".") { s = s + "." }
    let parts = s.split(".")
    let frac = parts.at(1)
    while frac.len() < dec { frac = frac + "0" }
    s = parts.at(0) + "." + frac
  }
  let parts = s.split(".")
  let int = parts.at(0)
  if int.len() > 4 {                       // group in threes from 5 digits up
    let groups = ()
    while int.len() > 3 {
      groups.insert(0, int.slice(int.len() - 3))
      int = int.slice(0, int.len() - 3)
    }
    groups.insert(0, int)
    int = groups.join(sym.space.nobreak.narrow)
  }
  let r = if parts.len() > 1 { int + "." + parts.at(1) } else { int }
  if neg { "−" + r } else { r }
}

// Quantity with unit, non-breaking space: qty(9.81, "m/s²", dec: 2) -> 9.81 m/s²
#let qty(x, unit, dec: none) = [#num(x, dec: dec)#sym.space.nobreak#unit]

// ---------- Content blocks ---------------------------------------------
// Items with their own identifier (ASM-01, REQ-01, CRIT-01, ...)
#let item(id, title, body) = block(
  above: 0.9em, below: 0.9em, breakable: true,
  grid(
    columns: (19mm, 1fr), column-gutter: 2mm, row-gutter: 0.45em,
    text(weight: "bold")[#id], text(weight: "bold")[#title],
    [], body,
  ),
)

// Clarifying note and open issue (no colour: stroke only)
#let note(body) = block(
  width: 100%, inset: (x: 3mm, y: 2.2mm), stroke: 0.5pt + BLACK, above: 1em, below: 1em,
)[#text(weight: "bold")[Note.] #body]

#let pending(body) = block(
  width: 100%, inset: (x: 3mm, y: 2.2mm), above: 1em, below: 1em,
  stroke: (paint: BLACK, thickness: 0.5pt, dash: "dashed"),
)[#text(weight: "bold")[Open.] #body]

// Source line under tables and figures
#let source(body) = align(left, text(8pt, fill: GREY)[Source: #body])

// Table from a CSV already read in the document (first row = header):
//   #csv-table(csv("data/mass.csv"), align: (left, right, right))
// (csv() is called in the document because Typst resolves paths from the calling file)
// If the CSV comes from a locale using decimal commas (";" separator):
//   #csv-table(csv("data/x.csv", delimiter: ";"), comma-to-point: true)
#let csv-table(rows, columns: auto, align: auto, comma-to-point: false) = {
  if comma-to-point {
    rows = rows.map(r => r.map(c => if c.match(regex("^[−-]?\\d+,\\d+$")) != none { c.replace(",", ".") } else { c }))
  }
  let n = rows.at(0).len()
  table(
    columns: if columns == auto { n } else { columns },
    align: if align == auto { (left,) + (right,) * (n - 1) } else { align },
    table.header(..rows.at(0)),
    ..rows.slice(1).flatten(),
  )
}

// Numbered reference list [1], [2]... (cite in the text as [1])
#let references(list) = {
  heading(numbering: none)[References]
  set text(9pt)
  grid(
    columns: (9mm, 1fr), row-gutter: 0.6em,
    ..list.enumerate().map(((i, r)) => ([[#(i + 1)]], r)).flatten(),
  )
}

// Switch to appendices: level-1 headings become «Appendix A», «Appendix B»...
#let appendices(body) = {
  counter(heading).update(0)
  set heading(numbering: (..n) => {
    let n = n.pos()
    if n.len() == 1 { "Appendix " + numbering("A", ..n) } else { numbering("A.1", ..n) }
  })
  pagebreak(weak: true)
  body
}

// ---------- Title block ---------------------------------------------------
#let _field(label, value, large: false) = block(
  width: 100%, height: 100%, inset: (x: 1.8mm, top: 1.6mm, bottom: 1mm),
  stack(
    spacing: 1.3mm,
    text(5.6pt, weight: "bold", upper(label)),
    text(if large { 9pt } else { 8pt }, weight: "bold", value),
  ),
)

#let _titleblock(d) = {
  let date = if d.created == d.modified { d.created } else { d.created + " / " + d.modified }
  let appr = {
    if d.signature != none { box(height: 5mm, d.signature) }
    text(8pt, weight: "bold", d.approved-by)
  }
  table(
    columns: (30mm, 1fr, 31mm, 15mm, 31mm),
    rows: (12mm, 10.5mm, 10.5mm),
    stroke: STROKE-TITLEBLOCK,
    fill: none,
    inset: 0pt,
    table.cell(rowspan: 3, align: center + horizon, image(LOGO, width: 24mm)),
    _field("Document", d.title, large: true),
    _field("Code", d.code, large: true),
    _field("Revision", d.revision, large: true),
    _field("Sheet", context [#counter(page).display() / #counter(page).final().first()], large: true),
    _field("Type", d.doctype),
    table.cell(colspan: 2, _field("Created / last revised", date)),
    _field("Status", d.status),
    _field("Prepared by", d.author),
    table.cell(colspan: 2, _field("Checked by", d.checker)),
    _field("Approved by", appr),
  )
}

// ---------- Document ------------------------------------------------------
#let alimoche-doc(
  code: "ALM-XX",
  title: "Document title",
  doctype: "Technical document",
  revision: "0.1",
  status: "Draft",
  created: "DD/MM/YYYY",
  modified: none,
  author: "Name Surname",
  checker: "Pending",
  approved-by: "Pending",
  signature: none,      // image("...") of the signature; ONLY if the project lead says so
  contents: false,      // table of contents after the title (recommended above ~6 sheets)
  body,
) = {
  assert(status in STATUSES, message: "Status not allowed: " + status)
  let d = (
    code: code, title: title, doctype: doctype, revision: revision, status: status,
    created: created, modified: if modified == none { created } else { modified },
    author: author, checker: checker, approved-by: approved-by, signature: signature,
  )

  set document(title: code + " · " + title, author: author, keywords: ("ALIMOCHE", code))
  set text(font: FONT, size: 10pt, lang: "en", region: "GB", fill: BLACK, hyphenate: true)
  set par(justify: true, leading: 0.62em, spacing: 0.95em, first-line-indent: 0pt)
  show raw: set text(font: FONT-MONO, size: 8.5pt)
  show math.equation: set text(font: "New Computer Modern Math")

  set page(
    paper: "a4",
    margin: (
      top: FRAME-MARGIN + TITLEBLOCK-H + 8mm,
      bottom: FRAME-MARGIN + 12mm,
      left: FRAME-MARGIN + 10mm,
      right: FRAME-MARGIN + 10mm,
    ),
    header: none,
    footer: none,
    background: {
      place(center + horizon, image(WATERMARK, width: 125mm))
      place(top + left, dx: FRAME-MARGIN, dy: FRAME-MARGIN,
        rect(width: 210mm - 2 * FRAME-MARGIN, height: 297mm - 2 * FRAME-MARGIN, stroke: STROKE-FRAME))
      place(top + left, dx: FRAME-MARGIN, dy: FRAME-MARGIN,
        block(width: 210mm - 2 * FRAME-MARGIN, height: TITLEBLOCK-H, _titleblock(d)))
      place(bottom + left, dx: FRAME-MARGIN + 4mm, dy: -(FRAME-MARGIN + 3.5mm),
        text(7pt, fill: GREY)[#code · Rev. #revision · #status])
      place(bottom + right, dx: -(FRAME-MARGIN + 4mm), dy: -(FRAME-MARGIN + 3.5mm),
        text(7pt, fill: GREY)[ALIMOCHE PROJECT])
    },
  )

  // Headings: two numbered levels at most; level 3 is unnumbered
  set heading(numbering: "1.1")
  show heading: set block(above: 1.35em, below: 0.7em)
  show heading.where(level: 1): set text(12pt, weight: "bold")
  show heading.where(level: 2): set text(10.5pt, weight: "bold")
  show heading.where(level: 3): it => block(above: 1.1em, below: 0.6em, text(10pt, weight: "bold", it.body))
  show heading: it => { set par(justify: false); it }

  // Lists
  set list(marker: [–], indent: 3mm, body-indent: 2mm)
  set enum(indent: 3mm, body-indent: 2mm, numbering: "a)")

  // Numbered equations (1), (2)...
  set math.equation(numbering: "(1)", supplement: [Eq.])

  // Tables: thin black rules, bold header on light grey
  set table(stroke: STROKE-TABLE, inset: (x: 1.6mm, y: 1.25mm))
  show table: set text(9pt)
  show table: set par(justify: false, leading: 0.5em)
  show table.cell.where(y: 0): set text(weight: "bold")
  set table(fill: (_, y) => if y == 0 { LIGHT-GREY })

  // Figures and tables: «Table 1.» above, «Figure 1.» below
  set figure(gap: 2.2mm)
  show figure.where(kind: table): set figure.caption(position: top)
  show figure.where(kind: table): set figure(supplement: [Table])
  show figure.where(kind: image): set figure(supplement: [Figure])
  set figure.caption(separator: [. ])
  show figure.caption: it => {
    set text(8.5pt)
    set par(justify: true)
    block(width: 100%, [#text(weight: "bold")[#it.supplement #context it.counter.display(it.numbering)#it.separator]#it.body])
  }
  show figure: set block(above: 1.3em, below: 1.3em)

  // Cross-references: «Table 2», «Figure 1», «Eq. 3», «Section 4»
  set ref(supplement: it => if it.func() == heading { [Section] } else { it.supplement })

  // ---- Title on the first sheet (title only; everything else is in the title block)
  align(center, block(below: 1.4em, text(14pt, weight: "bold", title)))
  if contents {
    outline(title: [Contents], depth: 2, indent: 5mm)
    v(4mm)
  }
  body
}
