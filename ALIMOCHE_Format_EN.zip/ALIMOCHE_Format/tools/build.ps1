# Build an ALIMOCHE document on Windows:  .\tools\build.ps1 ALM-P00-A06
# Requires typst.exe on the PATH (or -Typst path\typst.exe). Python optional, to regenerate charts.
param([Parameter(Mandatory=$true)][string]$Code, [string]$Typst = "typst")
$ErrorActionPreference = "Stop"
Set-Location (Join-Path $PSScriptRoot "..")
$dir = "documents/$Code"; $src = "$dir/$Code.typ"
if (-not (Test-Path $src)) { throw "Not found: $src" }
Get-ChildItem "$dir/figures/*.py" -ErrorAction SilentlyContinue | ForEach-Object { python $_.FullName }
$rev = ([regex]::Match((Get-Content $src -Raw -Encoding UTF8), 'revision:\s*"([^"]+)"')).Groups[1].Value
$out = "$dir/${Code}_Rev-$rev.pdf"
& $Typst compile --root . --font-path template/fonts $src $out
Write-Host "OK -> $out"
