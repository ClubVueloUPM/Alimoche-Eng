#!/usr/bin/env bash
# Build an ALIMOCHE document:  ./tools/build.sh ALM-P00-A06
# - Regenerates charts (documents/<CODE>/figures/*.py) if Python is available
# - Reads the revision from the .typ and writes documents/<CODE>/<CODE>_Rev-<rev>.pdf
set -euo pipefail
cd "$(dirname "$0")/.."
CODE="${1:?Usage: build.sh <CODE>}"
DIR="documents/$CODE"; SRC="$DIR/$CODE.typ"
[ -f "$SRC" ] || { echo "Not found: $SRC"; exit 1; }
TYPST="${TYPST:-typst}"
if ! command -v "$TYPST" >/dev/null 2>&1; then
  if [ ! -x tools/typst/typst ]; then
    mkdir -p tools/typst
    tar -xJf tools/typst-0.15.1-linux-x86_64.tar.xz -C tools/typst --strip-components=1
  fi
  TYPST=tools/typst/typst
fi
for py in "$DIR"/figures/*.py; do [ -e "$py" ] && python3 "$py"; done
REV=$(grep -oP 'revision:\s*"\K[^"]+' "$SRC" | head -1)
OUT="$DIR/${CODE}_Rev-${REV}.pdf"
"$TYPST" compile --root . --font-path template/fonts "$SRC" "$OUT"
echo "OK -> $OUT"
